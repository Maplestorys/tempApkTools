---
title: simple cryptography tools in blockchain
date: 2018-02-04 22:17:09
tags: Blockchain
---
### Hash Function
takes any string as input
fixed-sized output(usually 256 bits)
efficiently computable
### security properties:
collision-free
hiding
puzzle-friendly
### SHA-256
![](/img/1.png)
### Hash Pointer
![](/img/2.jpg)
### Merkle Tree
![](/img/3.png)
### Digital signature scheme
Only you can sign, but anyone can verify
* (sk, pk) := generateKeys(keysize)
* sig := sign(sk, message)
* isValid := verify(pk, message, sig)
### Public keys as Identities
A useful trick as Bitcoin do

### A Simple Cryptocurrency Example
* GoofyCoin
1.Goofy, can create new coins whenever he wants and these newly created coins belong to him
2.whoever owns a coin can transfer it on to someone else
![](/img/4.png)
double‐spending attack — Alice is spending the same coin twice.
* ScroogeCoin
Scrooge publishes an append‐only ledger containing the history of all the transactions that have happened.
ScroogeCoin block chain.
![](/img/5.png)
 CreateCoins transaction.
![](/img/6.png)
A PayCoins Transaction.
![](/img/7.png)
