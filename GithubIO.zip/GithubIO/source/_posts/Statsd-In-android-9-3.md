---
title: Statsd In android 9(3)
date: 2019-01-02 22:36:35
tags:
---
前面已经介绍了statsd的接口以及调用流程，本篇介绍接口自动生成的代码。

###StatsLogInternal
framework/base/core仓中的StatsLogInternal.java会被编译到framework.jar中，因而会在编译该jar包前生成。
查看framework/base/Android.bp

```
java_library {
    name: "framework",

    srcs: [
    ...
    ":framework-statslog-gen",
],

genrule {
    name: "framework-statslog-gen",
    tools: ["stats-log-api-gen"],
    cmd: "$(location stats-log-api-gen) --java $(out)",
    out: ["android/util/StatsLogInternal.java"],
}
```
可以理解为执行stats-log-api-gen这个工具，生成StatsLogInternal.java这个文件-
查看framework/base/tools/stats_log_api_gen/Android.bp
首先生成 stats-log-api-gen，再生成 statslog.h 以及 statslog.cpp，最后生成 libstatslog

```
    name: "statslog.h",
    tools: ["stats-log-api-gen"],
    cmd: "$(location stats-log-api-gen) --header $(genDir)/statslog.h",
    out: [
        "statslog.h",
    ],
}
genrule {
    name: "statslog.cpp",
    tools: ["stats-log-api-gen"],
    cmd: "$(location stats-log-api-gen) --cpp $(genDir)/statslog.cpp",
    out: [
        "statslog.cpp",
    ],
}
```
这里以java文件生成为例，查看代码的生成流程-
```
FILE* out = fopen(javaFilename.c_str(), "w");
if (out == NULL) {
    fprintf(stderr, "Unable to open file for write: %s\n", javaFilename.c_str());
    return 1;
}
errorCount = android::stats_log_api_gen::write_stats_log_java(
    out, atoms, attributionDecl);
fclose(out);
```
0.解析proto文件中的定义的常量(atoms)以及方法的参数(attributionDecl, attributionSignature)
解析atoms的方法均在Collation.cpp中定义
1.写入公用的字段，如import 以及类名
2.写入atom的常量
3.写入atom枚举的常量
4.写入write以及write_non_chained代码
```
write_java_method(out, "write", atoms.signatures, attributionDecl);
write_java_method(out, "write_non_chained", atoms.non_chained_signatures, attributionDecl);
write_java_work_source_method(out, atoms.signatures);
```
整个过程很简单，这里值得借鉴的是动态根据配置批量生成接口的方法
具体来说可以参考bp文件中的genrule的定义以及使用-
