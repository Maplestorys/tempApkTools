---
title: The generation of the backtrace
date: 2019-02-10 10:47:11
tags:
---
libbacktrace初始提交-
https://android-review.googlesource.com/c/platform/system/core/+/66528
debuggerd替换libbacktrace-
https://android-review.googlesource.com/c/platform/system/core/+/66946
rewrite libbacktrace in cpp
https://android-review.googlesource.com/c/platform/system/core/+/68667
selinux 关联修改1
https://android-review.googlesource.com/c/platform/external/sepolicy/+/68912
